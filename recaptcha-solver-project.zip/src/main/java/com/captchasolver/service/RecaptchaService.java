package com.captchasolver.service;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class RecaptchaService {
    
    private static final Logger log = LoggerFactory.getLogger(RecaptchaService.class);
    
    public String solveEnterprise(String url, String siteKey) throws Exception {
        WebDriver driver = null;
        
        try {
            WebDriverManager.chromedriver().setup();
            
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--headless=new");
            options.addArguments("--no-sandbox");
            options.addArguments("--disable-dev-shm-usage");
            options.addArguments("--disable-gpu");
            options.addArguments("--window-size=1920,1080");
            options.addArguments("--disable-blink-features=AutomationControlled");
            options.setExperimentalOption("excludeSwitches", 
                new String[]{"enable-automation"});
            options.setExperimentalOption("useAutomationExtension", false);
            
            driver = new ChromeDriver(options);
            
            log.info("Opening URL: {}", url);
            driver.get(url);
            
            // Inject script
            String script = """
                window.recaptchaToken = null;
                
                if (typeof grecaptcha !== 'undefined' && grecaptcha.enterprise) {
                    grecaptcha.enterprise.ready(function() {
                        grecaptcha.enterprise.execute('%s', {action: 'submit'})
                            .then(function(token) {
                                window.recaptchaToken = token;
                                console.log('Token obtained');
                            })
                            .catch(function(err) {
                                console.error('Error:', err);
                            });
                    });
                }
                """.formatted(siteKey);
            
            ((JavascriptExecutor) driver).executeScript(script);
            
            // Wait for token
            String token = null;
            for (int i = 0; i < 30; i++) {
                Thread.sleep(1000);
                token = (String) ((JavascriptExecutor) driver)
                    .executeScript("return window.recaptchaToken;");
                
                if (token != null && token.length() > 50) {
                    log.info("Token obtained in {} seconds", i + 1);
                    break;
                }
            }
            
            if (token == null || token.isEmpty()) {
                throw new RuntimeException("Failed to get reCAPTCHA token");
            }
            
            return token;
            
        } finally {
            if (driver != null) {
                driver.quit();
            }
        }
    }
}