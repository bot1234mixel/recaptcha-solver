package com.captchasolver.controller;

import com.captchasolver.model.RecaptchaRequest;
import com.captchasolver.model.RecaptchaResponse;
import com.captchasolver.service.RecaptchaService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class RecaptchaController {

    private final RecaptchaService recaptchaService;

    public RecaptchaController(RecaptchaService recaptchaService) {
        this.recaptchaService = recaptchaService;
    }

    @PostMapping("/recaptcha/solve")
    public RecaptchaResponse solve(@RequestBody RecaptchaRequest request) {
        String token = recaptchaService.solveEnterprise(
                request.getUrl(),
                request.getSiteKey()
        );

        return new RecaptchaResponse(true, token, "Success");
    }

    @GetMapping("/health")
    public String health() {
        return "OK";
    }
}
